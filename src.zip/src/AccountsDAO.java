import java.sql.*;

public class AccountsDAO {
    public static void getAccount(long accNumber) throws SQLException {
        Connection con = DBConnection.getConnection();
        String query = "SELECT * FROM accounts WHERE account_number = ?";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setLong(1, accNumber);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            System.out.println("\n===== ACCOUNT DETAILS =====");
            System.out.println("ACCOUNT NUMBER : " + rs.getLong("account_number"));
            System.out.println("BALANCE        : " + rs.getDouble("balance"));
            System.out.println("CLIENT ID      : " + rs.getString("client_id"));
            System.out.println("DATE           : " + rs.getTimestamp("transaction_date"));
        } else {
            System.out.println(
                    "Account Not Found..."
            );
        }
        con.close();
    }

    public static void addAccount(String id, long accnumber, double balance) throws SQLException {
        String query = "INSERT INTO accounts " + "VALUES(?,?,?,?)";
        Connection con = DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(query);
        pst.setLong(1, accnumber);
        pst.setDouble(2, balance);
        pst.setString(3, id);
        pst.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
        int rows = pst.executeUpdate();
        if (rows > 0) {System.out.println("Your account successfully inserted...");}

        con.close();
    }

    public static void readAccounts() throws SQLException {
        Connection con = DBConnection.getConnection();
        Statement stmt = con.createStatement();
        String query = "SELECT * FROM accounts";
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
            System.out.println("\n==============================");
            System.out.printf("ACCOUNT NUMBER : %d\n", rs.getLong("account_number"));
            System.out.printf("BALANCE        : %.2f\n", rs.getDouble("balance"));
            System.out.printf("CLIENT ID      : %s\n", rs.getString("client_id"));
            System.out.printf("DATE           : %s\n", rs.getTimestamp("transaction_date"));
        }
        con.close();
    }
    private static void addSavings()
    {
        try
        {
            System.out.print("Enter Account Number: ");

            long accNumber = scan.nextLong();

            scan.nextLine();

            System.out.print("Enter Client ID: ");

            String clientID = scan.nextLine();

            Connection con =
                    DBConnection.getConnection();

            // ==========================================
            // STEP 1 :
            // Check whether client exists
            // ==========================================

            String clientQuery =
                    "SELECT * FROM clients " +
                            "WHERE client_id = ?";

            PreparedStatement clientPst =
                    con.prepareStatement(clientQuery);

            clientPst.setString(1, clientID);

            ResultSet clientRs =
                    clientPst.executeQuery();

            if(!clientRs.next())
            {
                System.out.println(
                        "\nClient Not Found"
                );

                con.close();

                return;
            }

            // ==========================================
            // STEP 2 :
            // Check whether account exists
            // ==========================================

            String accountQuery =
                    "SELECT * FROM accounts " +
                            "WHERE account_number = ?";

            PreparedStatement accountPst =
                    con.prepareStatement(accountQuery);

            accountPst.setLong(1, accNumber);

            ResultSet accountRs =
                    accountPst.executeQuery();

            if(!accountRs.next())
            {
                System.out.println(
                        "\nAccount Not Found"
                );

                con.close();

                return;
            }

            // ==========================================
            // STEP 3 :
            // Get Interest Rate
            // ==========================================

            System.out.print(
                    "Enter Interest Rate (%): "
            );

            int interestRate =
                    scan.nextInt();

            double rate =
                    interestRate / 100.0;

            // ==========================================
            // STEP 4 :
            // Insert into savings table
            // ==========================================

            String insertQuery =
                    "INSERT INTO savings " +
                            "VALUES(?, ?)";

            PreparedStatement insertPst =
                    con.prepareStatement(insertQuery);

            insertPst.setLong(1, accNumber);

            insertPst.setDouble(2, rate);

            int rows =
                    insertPst.executeUpdate();

            // ==========================================
            // STEP 5 :
            // Success Message
            // ==========================================

            if(rows > 0)
            {
                System.out.println(
                        "\nSavings Account Added Successfully..."
                );
            }
            else
            {
                System.out.println(
                        "\nSavings Account Creation Failed..."
                );
            }

            con.close();
        }
        catch(Exception e)
        {
            System.out.println(
                    "ERROR: " + e.getMessage()
            );
        }
    }
}