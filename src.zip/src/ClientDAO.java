import java.sql.*;

public class ClientDAO {
    public static void getClient(String id) throws SQLException
    {
        Connection con  = DBConnection.getConnection();
        String query = "Select * from clients where client_id = ?";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1,id);
        int rows = pst.executeUpdate();
        if(rows>0)
        {
            System.out.println("Client details are fetched from database...");
        }
    }
    public static void addClient(String id, String name, String address,long accNumber) throws SQLException
    {
        String query = "insert into clients value(?,?,?)";
        Connection con  =DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1,id);
        pst.setString(2,name);
        pst.setString(3,address);
        int rows = pst.executeUpdate();
        if(rows>0)
        {
            System.out.println("Your details successfully inserted...");
        }
        AccountsDAO.addAccount(id,accNumber,0.0);
    }
    public static void readClients() throws SQLException
    {
        Connection con = DBConnection.getConnection();
        Statement stmt  = con.createStatement();
        String query = "select * from clients";
        ResultSet rs = stmt.executeQuery(query);
        while(rs.next())
        {
            System.out.printf("ID: %s| NAME: %s| ADDRESS: %s",rs.getString(1),rs.getString(2),rs.getString(3));
        }
    }
}
